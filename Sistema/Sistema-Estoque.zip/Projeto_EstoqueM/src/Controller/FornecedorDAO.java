package Controller;

import Model.bean.Fornecedor;
import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class FornecedorDAO {
    
   // ação de inserir os dados diretamento no banco de dados
   public void create (Fornecedor f) throws SQLException{
   
    Connection con = ConnectionFactory.getConnection();
    PreparedStatement stmt = null;
 
            try {
            stmt = con.prepareStatement("INSERT INTO fornecedor(forn_nome, forn_cep, forn_rua, forn_numero, forn_cidade, forn_telefone)VALUES (?,?,?,?,?,?)");
            
            stmt.setString(1,f.getForn_nome());
            stmt.setInt(2,f.getForn_cep());
            stmt.setString(3,f.getForn_rua());
            stmt.setInt(4,f.getForn_numero());
            stmt.setString(5,f.getForn_cidade());
            stmt.setInt(6,f.getForn_telefone());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Salvo com Sucesso ");
                    
            }catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Erro ao Salvar"+ ex);
        }finally{
          ConnectionFactory.closeConnection(con, stmt);
        }  
   }
   
   // ação de alterar os dados diretamento no banco de dados
   public void update (Fornecedor f) throws SQLException{
   
    Connection con = ConnectionFactory.getConnection();
    PreparedStatement stmt = null;

            try {
            stmt = con.prepareStatement("UPDATE Fornecedor SET forn_nome =?, forn_cep=? , forn_rua=? , forn_numero=? , forn_cidade=? , forn_telefone=?  WHERE forn_codigo = ?");
            
            stmt.setString(1,f.getForn_nome());
            stmt.setInt(2,f.getForn_cep());
            stmt.setString(3,f.getForn_rua());
            stmt.setInt(4,f.getForn_numero());
            stmt.setString(5,f.getForn_cidade());
            stmt.setInt(6,f.getForn_telefone());
            stmt.setInt(7,f.getForn_codigo());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Alterado com Sucesso ");
                    
            }catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Erro ao Alterar"+ ex);
        }finally{
          ConnectionFactory.closeConnection(con, stmt);
        }   
   }
   
   // ação de excluir os dados diretamento no banco de dados
   public void delete (Fornecedor f) throws SQLException{
   
    Connection con = ConnectionFactory.getConnection();
    PreparedStatement stmt = null;
   
    
            try {
            stmt = con.prepareStatement("DELETE FROM Fornecedor WHERE forn_codigo = ?");
            
            stmt.setInt(1,f.getForn_codigo());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Removido com Sucesso ");
                    
            }catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Erro ao Remover"+ ex);
        }finally{
          ConnectionFactory.closeConnection(con, stmt);
        } 
    
   }
   // listagem dos fornecedores cadastrados
   public List<Fornecedor> read(){
   
    Connection con = ConnectionFactory.getConnection();
    PreparedStatement stmt = null;
    ResultSet rs = null;
     
       List<Fornecedor> fornecedores = new ArrayList<>();
        
       try {
           stmt = con.prepareStatement("SELECT * FROM Fornecedor");
           rs = stmt.executeQuery();
           
           while(rs.next()){
                
               Fornecedor fornecedor = new Fornecedor();
                
                fornecedor.setForn_codigo(rs.getInt("forn_codigo"));
                fornecedor.setForn_nome(rs.getString("forn_nome"));
                fornecedor.setForn_cep(rs.getInt("forn_cep"));
                fornecedor.setForn_rua(rs.getString("forn_rua"));
                fornecedor.setForn_numero(rs.getInt("forn_numero"));
                fornecedor.setForn_cidade(rs.getString("forn_cidade"));
                fornecedor.setForn_telefone(rs.getInt("forn_telefone"));
                fornecedores.add(fornecedor);
            }
           
       } catch (SQLException ex) {
           Logger.getLogger(FornecedorDAO.class.getName()).log(Level.SEVERE, null, ex);
       }finally{
            ConnectionFactory.closeConnection(con, stmt, rs);
       }
       
       return fornecedores;
       
   }

}
    
     
