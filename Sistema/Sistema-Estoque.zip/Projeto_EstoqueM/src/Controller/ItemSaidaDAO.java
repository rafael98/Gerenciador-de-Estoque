package Controller;

import Model.bean.ItemSaida;
import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class ItemSaidaDAO {
    
    // ação de inserir os dados diretamento no banco de dados
    public void create (ItemSaida IS) throws SQLException{
    
    Connection con = ConnectionFactory.getConnection();
    PreparedStatement stmt = null;
     
    try {
            stmt = con.prepareStatement("INSERT INTO ItemSaida (itensSaida_nome, itensSaida_data, itensSaida_quantidade, itensSaida_valorVenda)VALUES (?,?,?,?)");
            
            stmt.setString(1,IS.getItensSaida_nome());
            stmt.setString(2,IS.getItensSaida_data());
            stmt.setInt(3,IS.getItensSaida_quantidade());
            stmt.setDouble(4,IS.getItensSaida_valorVenda());

            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Salvo com Sucesso ");
                    
            } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Erro ao Salvar"+ ex);
        }finally{
          ConnectionFactory.closeConnection(con, stmt);
        }    
    
    }
    
    // ação de alterar os dados diretamento no banco de dados
    public void update (ItemSaida IS) throws SQLException{
    
    Connection con = ConnectionFactory.getConnection();
    PreparedStatement stmt = null;
     
    try {
            stmt = con.prepareStatement("UPDATE ItemSaida SET itensSaida_nome= ?, itensSaida_data =?, itensSaida_quantidade=?, itensSaida_valorVenda =? WHERE itensSaida_codigo = ?");
            
            stmt.setString(1,IS.getItensSaida_nome());
            stmt.setString(2,IS.getItensSaida_data());
            stmt.setInt(3,IS.getItensSaida_quantidade());
            stmt.setDouble(4,IS.getItensSaida_valorVenda());
            stmt.setInt(5,IS.getItensSaida_codigo());
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Alterado com Sucesso ");
                    
            } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Erro ao Alterado"+ ex);
        }finally{
          ConnectionFactory.closeConnection(con, stmt);
        }    
    
    }
        
    // ação de excluir os dados diretamento no banco de dados
    public void delete (ItemSaida IS) throws SQLException{
    
    Connection con = ConnectionFactory.getConnection();
    PreparedStatement stmt = null;
     
    try {
            stmt = con.prepareStatement("DELETE FROM ItemSaida WHERE itensSaida_codigo = ?");

            stmt.setInt(1,IS.getItensSaida_codigo());
            stmt.executeUpdate();            
            JOptionPane.showMessageDialog(null, "Removido com Sucesso ");
                    
            } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Erro ao Remover"+ ex);
        }finally{
          ConnectionFactory.closeConnection(con, stmt);
        }      
    }
    
    // listagem dos itens saida cadastrados
    public List<ItemSaida> read(){
   
    Connection con = ConnectionFactory.getConnection();
    PreparedStatement stmt = null;
    ResultSet rs = null;
     
       List<ItemSaida> ItensSaida = new ArrayList<>();
        
       try {
           stmt = con.prepareStatement("SELECT * FROM ItemSaida");
           rs = stmt.executeQuery();
           
           while(rs.next()){
                
               ItemSaida ItemSaida = new ItemSaida();
                
                ItemSaida.setItensSaida_codigo(rs.getInt("itensSaida_codigo"));
                ItemSaida.setItensSaida_nome(rs.getString("itensSaida_nome"));
                ItemSaida.setItensSaida_data(rs.getString("itensSaida_data"));
                ItemSaida.setItensSaida_quantidade(rs.getInt("itensSaida_quantidade"));
                ItemSaida.setItensSaida_valorVenda(rs.getDouble("itensSaida_valorVenda"));
                ItensSaida.add(ItemSaida);
            }
           
       } catch (SQLException ex) {
           Logger.getLogger(ItemSaidaDAO.class.getName()).log(Level.SEVERE, null, ex);
       }finally{
            ConnectionFactory.closeConnection(con, stmt, rs);
       }
       
       return ItensSaida;
       
   }
       
}
