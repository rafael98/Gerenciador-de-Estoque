package view;

import Model.bean.Fornecedor;
import Model.bean.ItemEntrada;
import Controller.FornecedorDAO;
import Controller.ItemEntradaDAO;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

//classe de cadastro de entrada de item:
public class EntradaItem extends javax.swing.JInternalFrame {

    public EntradaItem() {
        initComponents();
        DefaultTableModel modelo = (DefaultTableModel)jTableItensEntradaCad.getModel();
        jTableItensEntradaCad.setRowSorter(new TableRowSorter(modelo));
        readTable();
   
     ManipulaInterfaceEnt("Navegar");
        
    } 
    
    // ler e carregar os dados na tabela interface
    public void readTable(){
     DefaultTableModel modelo = (DefaultTableModel)jTableItensEntradaCad.getModel();
     modelo.setNumRows(0);
     ItemEntradaDAO iedao = new ItemEntradaDAO();
     
     for(ItemEntrada IE: iedao.read()){
         modelo.addRow(new Object[]{
             IE.getItensEnt_codigo(),
             IE.getItensEnt_nome(),
             IE.getItensEnt_data(),
             IE.getItensEnt_quantidade(),
             IE.getItensEnt_valorCusto(),
         });
     }
    }

    // ação dos botões de novo, alterar, remover 
   // bloquear e desbloquear as sequencias de ordens dos botões com as respectivas ação realizadas
    public void ManipulaInterfaceEnt (String modo){
             switch (modo){
               case "Navegar":
                itensEnt_codigo.setEnabled(false);
                jButtonNovo.setEnabled(true);
                jButtonSalvar.setEnabled(true);
                jButtonAlterar.setEnabled(false);
                jButtonRemover.setEnabled(false);
                break;
            
                case "Novo":
                itensEnt_codigo.setEnabled(false);
                jButtonNovo.setEnabled(false);
                jButtonSalvar.setEnabled(true);
                jButtonAlterar.setEnabled(false);
                jButtonRemover.setEnabled(false);
                  
              break; 
              
           case "Alterar":
              itensEnt_codigo.setEnabled(false);
              jButtonNovo.setEnabled(true);
              jButtonSalvar.setEnabled(false);
              jButtonAlterar.setEnabled(true);
              jButtonRemover.setEnabled(true);       
               
               break;
                   
           case "Remover":
              itensEnt_codigo.setEnabled(false);
              jButtonNovo.setEnabled(true);
              jButtonSalvar.setEnabled(false);
              jButtonAlterar.setEnabled(true);
              jButtonRemover.setEnabled(true);
               break;
           default: System.out.println("Modo Inválido ");        
           }

    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jPanelDadosItemEntrada = new javax.swing.JPanel();
        jLabelNome = new javax.swing.JLabel();
        jLabelData = new javax.swing.JLabel();
        jLabelQnt = new javax.swing.JLabel();
        jLabelValorC = new javax.swing.JLabel();
        itensEnt_valorCusto = new javax.swing.JTextField();
        jButtonSalvar = new javax.swing.JButton();
        jButtonAlterar = new javax.swing.JButton();
        jButtonRemover = new javax.swing.JButton();
        jButtonNovo = new javax.swing.JButton();
        itensEnt_quantidade = new javax.swing.JFormattedTextField();
        jLabel1 = new javax.swing.JLabel();
        itensEnt_codigo = new javax.swing.JTextField();
        itensEnt_data = new javax.swing.JFormattedTextField();
        itensEnt_nome = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jSeparator2 = new javax.swing.JSeparator();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableItensEntradaCad = new javax.swing.JTable();

        jTextField1.setText("jTextField1");

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Entrada de Item");

        jPanelDadosItemEntrada.setBackground(new java.awt.Color(153, 153, 255));
        jPanelDadosItemEntrada.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados Entrada de Item"));

        jLabelNome.setText("Nome");

        jLabelData.setText("Data");

        jLabelQnt.setText("Quantidade");

        jLabelValorC.setText("Valor Custo");

        itensEnt_valorCusto.setBackground(new java.awt.Color(204, 204, 255));
        itensEnt_valorCusto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itensEnt_valorCustoActionPerformed(evt);
            }
        });

        jButtonSalvar.setBackground(new java.awt.Color(204, 204, 255));
        jButtonSalvar.setText("Salvar");
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });

        jButtonAlterar.setBackground(new java.awt.Color(204, 204, 255));
        jButtonAlterar.setText("Alterar");
        jButtonAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAlterarActionPerformed(evt);
            }
        });

        jButtonRemover.setBackground(new java.awt.Color(204, 204, 255));
        jButtonRemover.setText("Remover");
        jButtonRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRemoverActionPerformed(evt);
            }
        });

        jButtonNovo.setText("Novo");
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoActionPerformed(evt);
            }
        });

        itensEnt_quantidade.setBackground(new java.awt.Color(204, 204, 255));
        itensEnt_quantidade.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter()));

        jLabel1.setText("Codigo Item Entrada");

        itensEnt_codigo.setBackground(new java.awt.Color(204, 204, 255));

        itensEnt_data.setBackground(new java.awt.Color(204, 204, 255));
        try {
            itensEnt_data.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##-##-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        itensEnt_nome.setBackground(new java.awt.Color(204, 204, 255));

        javax.swing.GroupLayout jPanelDadosItemEntradaLayout = new javax.swing.GroupLayout(jPanelDadosItemEntrada);
        jPanelDadosItemEntrada.setLayout(jPanelDadosItemEntradaLayout);
        jPanelDadosItemEntradaLayout.setHorizontalGroup(
            jPanelDadosItemEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelDadosItemEntradaLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButtonNovo)
                .addGap(18, 18, 18)
                .addComponent(jButtonSalvar, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButtonAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButtonRemover)
                .addGap(51, 51, 51))
            .addGroup(jPanelDadosItemEntradaLayout.createSequentialGroup()
                .addGroup(jPanelDadosItemEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanelDadosItemEntradaLayout.createSequentialGroup()
                        .addGroup(jPanelDadosItemEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelQnt)
                            .addComponent(itensEnt_quantidade, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(73, 73, 73)
                        .addGroup(jPanelDadosItemEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(itensEnt_valorCusto, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelValorC)))
                    .addGroup(jPanelDadosItemEntradaLayout.createSequentialGroup()
                        .addGroup(jPanelDadosItemEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelNome)
                            .addComponent(itensEnt_nome, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(109, 109, 109)
                        .addGroup(jPanelDadosItemEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelData)
                            .addComponent(itensEnt_data, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel1)
                    .addComponent(itensEnt_codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(346, Short.MAX_VALUE))
        );
        jPanelDadosItemEntradaLayout.setVerticalGroup(
            jPanelDadosItemEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelDadosItemEntradaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelDadosItemEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelDadosItemEntradaLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(itensEnt_codigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanelDadosItemEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanelDadosItemEntradaLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabelData)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(itensEnt_data, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanelDadosItemEntradaLayout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(jLabelNome)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(itensEnt_nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPanelDadosItemEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanelDadosItemEntradaLayout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addComponent(jLabelValorC)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(itensEnt_valorCusto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanelDadosItemEntradaLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                                .addComponent(jLabelQnt)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(itensEnt_quantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(53, 53, 53))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelDadosItemEntradaLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanelDadosItemEntradaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButtonSalvar)
                            .addComponent(jButtonAlterar)
                            .addComponent(jButtonRemover)
                            .addComponent(jButtonNovo)))))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Itens de Entrada Cadastrados:"));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 819, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jTableItensEntradaCad.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código Item Entrada", "Nome Fornecedor", "Data", "Quantidade", "Valor Custo", ""
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableItensEntradaCad.setGridColor(new java.awt.Color(0, 0, 0));
        jTableItensEntradaCad.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
                jTableItensEntradaCadAncestorMoved(evt);
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
                jTableItensEntradaCadAncestorRemoved(evt);
            }
        });
        jTableItensEntradaCad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableItensEntradaCadMouseClicked(evt);
            }
        });
        jTableItensEntradaCad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTableItensEntradaCadKeyReleased(evt);
            }
        });
        jScrollPane2.setViewportView(jTableItensEntradaCad);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanelDadosItemEntrada, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jSeparator2, javax.swing.GroupLayout.Alignment.LEADING))
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanelDadosItemEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(178, 178, 178))
        );

        getAccessibleContext().setAccessibleName("Entrada de Item Produto");

        setBounds(0, 0, 867, 658);
    }// </editor-fold>//GEN-END:initComponents

    // botao de salvar os dados dos Itens de Entrada:
    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
        try {
            
            
            ItemEntrada IE = new ItemEntrada();
            ItemEntradaDAO DAO = new ItemEntradaDAO();
            
            IE.setItensEnt_nome(itensEnt_nome.getText());
            IE.setItensEnt_data(itensEnt_data.getText());
            IE.setItensEnt_quantidade(Integer.parseInt(itensEnt_quantidade.getText()));
            IE.setItensEnt_valorCusto(Double.parseDouble(itensEnt_valorCusto.getText()));
            DAO.create(IE);
            readTable();

            {
            }
        } catch (SQLException ex) {
            Logger.getLogger(EntradaItem.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    // botao para alterar dados dos Itens de Entrada:
    private void jButtonAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAlterarActionPerformed
        
        
        if(jTableItensEntradaCad.getSelectedRow()!= -1){
           
            ItemEntrada IE = new ItemEntrada();
            ItemEntradaDAO DAO = new ItemEntradaDAO();
            
            IE.setItensEnt_nome(itensEnt_nome.getText());
            IE.setItensEnt_data(itensEnt_data.getText());
            IE.setItensEnt_quantidade(Integer.parseInt(itensEnt_quantidade.getText()));
            IE.setItensEnt_valorCusto(Double.parseDouble(itensEnt_valorCusto.getText()));
            IE.setItensEnt_codigo((int)jTableItensEntradaCad.getValueAt(jTableItensEntradaCad.getSelectedRow(), 0));
            try {
                DAO.update(IE);
                
            } catch (SQLException ex) {
                Logger.getLogger(EntradaItem.class.getName()).log(Level.SEVERE, null, ex);
            }
 
            }else{
            JOptionPane.showMessageDialog(null, "Selecione um Campo para Alterar.");   
        }
        {
        }
        readTable();
    }//GEN-LAST:event_jButtonAlterarActionPerformed

    // botao para excluir dados dos itens de Entrada:
    private void jButtonRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRemoverActionPerformed
       
        if (jTableItensEntradaCad.getSelectedRow()!= -1) {
            
            ItemEntrada IE = new ItemEntrada();
            ItemEntradaDAO DAO = new ItemEntradaDAO();

            IE.setItensEnt_codigo((int)jTableItensEntradaCad.getValueAt(jTableItensEntradaCad.getSelectedRow(), 0));
            try {
                DAO.delete(IE);
                
            } catch (SQLException ex) {
                Logger.getLogger(EntradaItem.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            }else{
            JOptionPane.showMessageDialog(null, "Selecione um Campo para Excluir.");
             
        }{
         }
         readTable();
    }//GEN-LAST:event_jButtonRemoverActionPerformed

    private void jTableItensEntradaCadAncestorMoved(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jTableItensEntradaCadAncestorMoved

         
    }//GEN-LAST:event_jTableItensEntradaCadAncestorMoved

    // botao de limpar os dados de cadastro dos itens de entrada:
    private void jButtonNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoActionPerformed
        
        
        itensEnt_nome.setText("");
        itensEnt_data.setText("");
        itensEnt_quantidade.setText("");
        itensEnt_valorCusto.setText("");
                
       ManipulaInterfaceEnt("Novo");
         
    }//GEN-LAST:event_jButtonNovoActionPerformed

    // Seleciona com o mouse o campo que deseja fazer as ações: alterar ou remover dados:
    private void jTableItensEntradaCadMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableItensEntradaCadMouseClicked
       
        if (jTableItensEntradaCad.getSelectedRow()!= -1){
            itensEnt_codigo.setText(jTableItensEntradaCad.getValueAt(jTableItensEntradaCad.getSelectedRow(), 0).toString());
            itensEnt_nome.setText(jTableItensEntradaCad.getValueAt(jTableItensEntradaCad.getSelectedRow(), 1).toString());
            itensEnt_data.setText(jTableItensEntradaCad.getValueAt(jTableItensEntradaCad.getSelectedRow(), 2).toString());
            itensEnt_quantidade.setText(jTableItensEntradaCad.getValueAt(jTableItensEntradaCad.getSelectedRow(),3).toString());
            itensEnt_valorCusto.setText(jTableItensEntradaCad.getValueAt(jTableItensEntradaCad.getSelectedRow(), 4).toString());
        } 
        ManipulaInterfaceEnt("Remover");
        ManipulaInterfaceEnt("Alterar");
        
    }//GEN-LAST:event_jTableItensEntradaCadMouseClicked

    private void jTableItensEntradaCadAncestorRemoved(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jTableItensEntradaCadAncestorRemoved
  
    }//GEN-LAST:event_jTableItensEntradaCadAncestorRemoved

    private void itensEnt_valorCustoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itensEnt_valorCustoActionPerformed
 
    }//GEN-LAST:event_itensEnt_valorCustoActionPerformed

    
    // fazer a alteração dos dados da tabela :
    private void jTableItensEntradaCadKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTableItensEntradaCadKeyReleased
        
        
        itensEnt_nome.setText(jTableItensEntradaCad.getValueAt(jTableItensEntradaCad.getSelectedRow(), 1).toString());
        itensEnt_data.setText(jTableItensEntradaCad.getValueAt(jTableItensEntradaCad.getSelectedRow(), 2).toString());
        itensEnt_quantidade.setText(jTableItensEntradaCad.getValueAt(jTableItensEntradaCad.getSelectedRow(),3).toString());
        itensEnt_valorCusto.setText(jTableItensEntradaCad.getValueAt(jTableItensEntradaCad.getSelectedRow(), 4).toString());

        
    }//GEN-LAST:event_jTableItensEntradaCadKeyReleased

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField itensEnt_codigo;
    private javax.swing.JFormattedTextField itensEnt_data;
    private javax.swing.JTextField itensEnt_nome;
    private javax.swing.JFormattedTextField itensEnt_quantidade;
    private javax.swing.JTextField itensEnt_valorCusto;
    private javax.swing.JButton jButtonAlterar;
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JButton jButtonRemover;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelData;
    private javax.swing.JLabel jLabelNome;
    private javax.swing.JLabel jLabelQnt;
    private javax.swing.JLabel jLabelValorC;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanelDadosItemEntrada;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTable jTableItensEntradaCad;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables

}
